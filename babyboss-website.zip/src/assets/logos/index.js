export { ReactComponent as Logo } from './logo.svg';
export { ReactComponent as TwitterLogo } from './twitter.svg';
export { ReactComponent as DiscordLogo } from './discord.svg';
export { ReactComponent as GithubLogo } from './github.svg';
export { ReactComponent as OpenSeaLogo } from './opensea.svg';
export { ReactComponent as InstagramLogo } from './instagram.svg';
