export const genesisLimit = {
  "0x17558889b14d06ca5d9f77a5301bff21bb7c4716": "5",
  "0x1eb5def9b96ce3133172a68a7dad31c3659f6bfc": "8",
  "0xc6e47c6d134a874c10b094ef419700feb79e5925": "21"
}