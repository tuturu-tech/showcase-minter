export const whitelistLimit = {
  "0x0899511005209d9a5e259430a7d26471aa7d404a": "1",
  "0xb32f35dea4ad87d25d1fa11483dce922b6316fc6": "1"
}